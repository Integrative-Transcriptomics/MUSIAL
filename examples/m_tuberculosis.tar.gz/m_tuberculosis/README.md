## **Example Dataset Source**:
For the example dataset we have downloaded all paired-end read datasets listed on the M. tuberculosis NextStrain board (https://nextstrain.org/tb/global). Genotyping was conducted with nf-core/eager (https://nf-co.re/eager) specifying the GATK HaplotypeCaller (https://gatk.broadinstitute.org/). We have selected three genes, ethA, inhA, katG, relevant for AM resistance (https://www.ncbi.nlm.nih.gov/pmc/articles/PMC296216/) for the example analysis. The protein structures for the products of the three genes were downloaded from UniProt (the AlphaFold2 predicted models) - note: The MODEL and ENDMODEL lines were removed from the .pdb files.

## **Working with MUSIAL**:
We have prepared all necessary configurations to directly work with the example dataset. The first step of each workflow is to build a MUSIAL storage with the build task. For this switch into the `/examples/m_tuberculosis/` directory and execute the following command.
**Ensure that the path to the MUSIAL JAR is correct**.

`java -jar MUSIAL-v2.2.jar build -c .\configuration.json`

This will generate the file `/examples/m_tuberculosis/output.json`, which will serve as the main input for all other tasks. Optionally, you can take a look at the build configuration description at the GitHub repository and change some settings. The example build configuration also constitutes a good starting point for your own analysis. Next, we provide you with some example commands to extract information of the storage file.

- Get an overview of all analyzed genes:
  `java -jar MUSIAL-v2.2.jar view_features -I ./output.json`

- Get an overview of all analyzed samples:
  `java -jar MUSIAL-v2.2.jar view_samples -I ./output.json`

- Get an overview of all nucleotide variants of the gene katG:
  `java -jar MUSIAL-v2.2.jar view_variants -I ./output.json -f katG -o ./output/katG_nucleotide_variants.tsv`

- Get an overview of all aminoacid variants of the protein KatG:
  `java -jar MUSIAL-v2.2.jar view_variants -I ./output.json -f katG -c aminoacid -o ./output/KatG_aminoacid_variants.tsv`

- Get an alignment of the KatG sequences of the samples that yield an isoniazid resistance mutation on KatG:
  `java -jar ../../releases/MUSIAL-v2.2.jar export_sequence -I ./output.json -F katG -k -a -c aminoacid -O ./output/KatG_INH_AMR_alignment.fasta -s ERR029204 ERR1193674 ERR1193678 ERR1193730 ERR1203075 ERR1367648 ERR1367657 ERR1465763 ERR1465789 ERR1465901 ERR1465902 ERR1465932 ERR1465942 ERR158589 ERR158609 ERR161147 ERR176468 ERR176501 ERR176530 ERR176809 ERR212008 ERR212021 ERR234206 ERR275183 ERR275190 ERR275194 ERR275198 ERR275201 ERR275214 ERR275215 ERR275216 ERR275226 ERR439968 ERR550896 ERR550978 ERR551591 ERR551645 ERR551797 ERR551956 ERR551957 ERR552080 ERR552099 ERR552504 ERR552586 ERR552738 ERR553023 ERR553246 ERR688038 ERR688042 ERR757167 ERR789235 SRR1011496 SRR1013559 SRR1013560 SRR1013642 SRR1013643 SRR1013666 SRR1013667 SRR1049729 SRR1049730 SRR1049731 SRR1049732 SRR1050530 SRR1159180 SRR1159299 SRR1162518 SRR1162534 SRR1162855 SRR1162865 SRR1162954 SRR1163173 SRR1163416 SRR1163425 SRR1165512 SRR1165592 SRR1166111 SRR1166137 SRR1166178 SRR1166208 SRR1166228 SRR1166297 SRR1166304 SRR1166316 SRR1166325 SRR1169499 SRR1169527 SRR1169563 SRR1169585 SRR1169590 SRR1172176 SRR1172225 SRR1172226 SRR1172315 SRR1172848 SRR1172873 SRR1172942 SRR1173043 SRR1173178 SRR1174822 SRR1175155 SRR1180972 SRR1181120 SRR1181279 SRR2099978 SRR2099982 SRR2100178 SRR2100359 SRR2100376 SRR2100397 SRR2100838 SRR2100919 SRR2100920 SRR2101311 SRR3724666 SRR3724950 SRR3725655 SRR3732579 SRR5535396 SRR5535696 SRR5535719 SRR5535808 SRR5535829 SRR5535831 SRR5535834 SRR5535835 SRR5535854 SRR5535919 SRR5535924 SRR5535930`

- Get a matrix of the ethA nucleotide variants:
  `java -jar MUSIAL-v2.2.jar export_table -I ./output.json -F ethA -c nucleotide -O ./output/ethA_nucleotide_variants_matrix.tsv`