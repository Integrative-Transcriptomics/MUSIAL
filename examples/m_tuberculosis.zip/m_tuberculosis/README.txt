# About the example dataset:

For the example dataset we have downloaded all paired-end read datasets listed on the M. tuberculosis NextStrain board (https://nextstrain.org/tb/global) and filtered for samples that were taken in Germany (n=54).
We have selected three genes, ethA, inhA, katG, relevant for Ethionamide resistance (https://www.ncbi.nlm.nih.gov/pmc/articles/PMC296216/) for the example analysis.
The protein structures for the products of the three genes were downloaded from UniProt (the AlphaFold2 predicted models) - note: The MODEL and ENDMODEL lines were removed from the .pdb files.
The configuration.json in the example folder specifies all the 54 samples and the three genes with their structures for 1. building the MUSIAL intermediate JSON database, 2. extracting a table of all SNPs per gene and sample set sharing a common set of variants (we call those sets alleles) and 3. extracting the changed aminoacid sequences per protein and sample.

# How to run MUSIAL on the example dataset:

I. If you have compiled MUSIAL from source with gradle.
- The executable .jar file should be located in <DOWNLOAD_DIRECTORY>/MUSIAL-2.1/releases/MUSIAL-v2.1.jar
- You can run the example with `java -jar <DOWNLOAD_DIRECTORY>/MUSIAL-2.1/releases/MUSIAL-v2.1.jar -c <DOWNLOAD_DIRECTORY>/MUSIAL-2.1/examples/m_tuberculosis/configuration.json`

II. If you have downloaded the MUSIAL-v2.1.jar from the repository releases.
- The paths in the examples configuration.json are relative to repositories root directory, i.e., `./examples/m_tuberculosis/...` and so on.
- You can either change those paths to absolute paths and run MUSIAL from any directory in your system...
- ...or place the downloaded MUSIAL-v2.1.jar inside the repository root directory and type `java -jar ./MUSIAL-v2.1.jar -c ./examples/m_tuberculosis/configuration.json`

After the run has completed you will find the following files in the `<DOWNLOAD_DIRECTORY>/MUSIAL-2.1/examples/m_tuberculosis/output/` directory:
- m_tuberculosis_H37Rv_germany.json | The uncompressed output of the MUSIAL BUILD module, i.e., a JSON database containing information about the occurence of variants in samples. 
- *.tsv for * being ethA, inhA, katG | The MUSIAL variants table output for each of the specified genes/features, i.e., for each variable position the nucleotide variant per allele (groups of samples with the same set of nuc. variants). Conserved positions and indels were removed.
- *.fasta for * being ethA, inhA, katG | The MUSIAL FASTA output for each of the specified genes/features, i.e., for each sample the aminoacid sequence of the respective genes' protein product with all incorporated variants.  